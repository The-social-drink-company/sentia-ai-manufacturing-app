function e(e,[t,n]){return Math.min(n,Math.max(t,e))}function t(e,t,{checkForDefaultPrevented:n=!0}={}){return function(r){if(e?.(r),!1===n||!r.defaultPrevented)return t?.(r)}}export{e as a,t as c};
