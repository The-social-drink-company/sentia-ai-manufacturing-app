import{i}from"./chunk-tZo8O77D.js";function t(t){return i(t)&&"offsetHeight"in t}export{t as i};
