console.log('Database migration skipped - no migrations needed');
